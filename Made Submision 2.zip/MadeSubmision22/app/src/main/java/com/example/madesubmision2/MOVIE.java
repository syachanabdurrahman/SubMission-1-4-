package com.example.madesubmision2;

import android.os.Parcel;
import android.os.Parcelable;

public class MOVIE implements Parcelable {
    private String NameMovie;
    private String DetailMovie;
    private int PhotoMovie;

    public MOVIE() {

    }

    public String getNameMovie() {
        return NameMovie;
    }

    public void setNameMovie(String nameMovie) {
        NameMovie = nameMovie;
    }

    public String getDetailMovie() {
        return DetailMovie;
    }

    public void setDetailMovie(String detailMovie) {
        DetailMovie = detailMovie;
    }

    public int getPhotoMovie() {
        return PhotoMovie;
    }

    public void setPhotoMovie(int photoMovie) {
        PhotoMovie = photoMovie;
    }

    public static Creator<MOVIE> getCREATOR() {
        return CREATOR;
    }

    protected MOVIE(Parcel in) {
        NameMovie = in.readString();
        DetailMovie = in.readString();
        PhotoMovie = in.readInt();
    }

    public static final Creator<MOVIE> CREATOR = new Creator<MOVIE>() {
        @Override
        public MOVIE createFromParcel(Parcel in) {
            return new MOVIE(in);
        }

        @Override
        public MOVIE[] newArray(int size) {
            return new MOVIE[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(NameMovie);
        parcel.writeString(DetailMovie);
        parcel.writeInt(PhotoMovie);
    }
}
