package com.example.madesubmision2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Detail_Activity extends AppCompatActivity {
    public TextView tvDetail;
    public ImageView imgMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_);

        tvDetail = findViewById(R.id.tv_item_detail);
        MOVIE extra = getIntent().getParcelableExtra("objek");
        tvDetail.setText(extra.getDetailMovie());

        imgMovie = findViewById(R.id.img_item_photo);
        imgMovie.setImageResource(extra.getPhotoMovie());
    }
}
