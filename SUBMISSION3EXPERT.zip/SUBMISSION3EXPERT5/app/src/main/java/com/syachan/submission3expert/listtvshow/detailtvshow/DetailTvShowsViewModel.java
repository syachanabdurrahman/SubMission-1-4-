package com.syachan.submission3expert.listtvshow.detailtvshow;

import androidx.lifecycle.ViewModel;

import com.syachan.submission3expert.listtvshow.pojo.ResultsItem;


public class DetailTvShowsViewModel extends ViewModel {
    private ResultsItem resultsItem1;

    public ResultsItem getResultsItem() {
        return resultsItem1;
    }

    public void setResultsItem(ResultsItem resultsItem1) {
        this.resultsItem1 = resultsItem1;

    }
}
