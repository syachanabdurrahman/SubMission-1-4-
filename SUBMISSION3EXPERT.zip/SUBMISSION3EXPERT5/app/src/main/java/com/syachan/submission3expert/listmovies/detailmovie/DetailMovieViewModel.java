package com.syachan.submission3expert.listmovies.detailmovie;

import androidx.lifecycle.ViewModel;

import com.syachan.submission3expert.listmovies.pojo.ResultsItem;

public class DetailMovieViewModel extends ViewModel {
    private ResultsItem resultsItem;

    public ResultsItem getResultsItem() {
        return resultsItem;
    }

    public void setResultsItem(ResultsItem resultsItem) {
        this.resultsItem = resultsItem;
    }
}

