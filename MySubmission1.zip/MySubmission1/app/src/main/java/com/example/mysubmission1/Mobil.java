package com.example.mysubmission1;

import android.os.Parcel;
import android.os.Parcelable;

public class Mobil implements Parcelable {
    private String Name;
    private String Detail;
    private int photo;

    protected Mobil(Parcel in) {
        Name = in.readString();
        Detail = in.readString();
        photo = in.readInt();
    }

    public Mobil() {

    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDetail() {
        return Detail;
    }

    public void setDetail(String detail) {
        Detail = detail;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public static Creator<Mobil> getCreator() {
        return CREATOR;
    }

    public static final Creator<Mobil> CREATOR = new Creator<Mobil>() {
        @Override
        public Mobil createFromParcel(Parcel in) {
            return new Mobil(in);
        }

        @Override
        public Mobil[] newArray(int size) {
            return new Mobil[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(Name);
        parcel.writeString(Detail);
        parcel.writeInt(photo);
    }
}

