package com.example.mysubmission1;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
    public TextView tvDetail;
    public ImageView imgMobil;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mobil_detail);
        tvDetail = findViewById(R.id.tv_item_detail);
        Mobil extra = getIntent().getParcelableExtra("objek");
        tvDetail.setText(extra.getDetail());

        imgMobil = findViewById(R.id.img_item_photo);
        imgMobil.setImageResource(extra.getPhoto());
    }
}