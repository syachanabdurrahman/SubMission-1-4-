package com.example.mysubmission1;

import java.util.ArrayList;

public class MobilData {

    private static String[] mobilNames = {
            "Toyota Sport",
            "NSX V6",
            "Audi R8",
            "Nissan GT-R",
            "McLaren GT",
            "McLaren unveils",
            "Koenigsegg Angera",
            "Mercedes-AMG2",
            "McLaren F1",
            "Lexus"
    };
    private static String[] mobilDetail = {
            "mobil sport Coupe berukuran kompak hasil kolaborasi antara Toyota dan Subaru. Mobil ini disebut Toyota GT-86 di Eropa, atau Scion FR-S di Amerika Serikat, serta dijual oleh Subaru sebagai Subaru BRZ.",
            "Sebelum Honda NSX lahir, pada tahun 1984 Honda bekerjasama dengan desainer mobil Italia bernama Pininfarina untuk menciptakan mobil konsep dengan nama HP-X (Honda Pininfarina Xperimental).",
            "Audi R8 Decennium limited edition menggendong mesin V10, seperti yang dipasang pada super car-nya. Tampak depan mobil ini terlihat tampan dengan lampu LED berbentuk centang terbalik, dan beberapa lekukan tegas yang ada di bodi mobil.",
            "Nissan GT-R merupakan mobil sport terbaru yang dibuat di Jepang dan menggunakan mesin V6 Twin-Turbo, dan merupakan penerus dari jajaran Nissan Skyline GT-R",
            "McLaren GT-baru dibangun dengan berbagi DNA dengan Speedtail, menawarkan rancang bangun dari serat karbon yang ringan, inovatif, mewah, hingga kualitas dari material yang dipakai.",
            "Mobil-mobil McLaren, mengesankan dan sangat cepat. 100 persen didesain dan dibangun oleh tangan di Inggris dengan komponen dari Inggris Raya sebanyak mungkin, saat pabrikan lain mencoba mencari banyak bahan baku di seluruh penjuru dunia dengan pabrikan manufaktur yang berbeda-beda.",
            "Bulan Desember 2010 Koenigsegg Agera memenangkan penghargaan prestisius dari BBC Top Gear sebagai Hypercar of the Year Award.",
            "era 90an mengawali kerja sama Merc dengan AMG secara resmi. Diawali dengan turunnya AMG sebagai tim balap resmi Mercedes-Benz, kemudian Mercedes membeli sebagian besar saham AMG, dan lalu mengubahnya menjadi Mercedes-AMG GmbH.",
            "McLaren F1 Team merupakan salah satu tim balap Formula Satu yang berbasis di Woking, Inggris.",
            "Lexus adalah sebuah merek mobil mewah yang digunakan oleh Toyota Motor Corporation di Amerika Utara, Timur Tengah, Eropa, Australia, Asia (dipasarkan di Jepang pada 2005) dan Selandia Baru.",
    };

    private static int[] mobilImage ={
            R.drawable.toyota,
            R.drawable.nxc,
            R.drawable.audi,
            R.drawable.nissan,
            R.drawable.mclaren_b,
            R.drawable.mclarenunveils,
            R.drawable.koenigsegg_agera,
            R.drawable.mercedes,
            R.drawable.mclaren_c,
            R.drawable.lexus,
    };

    static ArrayList<Mobil> getListData() {
        ArrayList<Mobil>list = new  ArrayList<>();
        for (int position = 0; position < mobilNames.length;position++) {
            Mobil mobil = new Mobil();
            mobil.setName(mobilNames[position]);
            mobil.setDetail(mobilDetail[position]);
            mobil.setPhoto(mobilImage[position]);
            list.add(mobil);
        }
        return list;
    }
}
